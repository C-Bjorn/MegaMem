"""
Async adapter layer that wraps ObsidianCLI in the same interface as FileTools.
Drop-in replacement for FileTools when use_cli_file_tools=True.

No WebSocket dependency. Vault is resolved from the CLI vault registry.

@purpose: Provide identical async API to FileTools using CLI subprocess backend
@depends: ObsidianCLI (obsidian_cli.py), asyncio.to_thread for subprocess offload
@results: Same response envelopes as FileTools — MCP server needs no changes
"""

import asyncio
import json
import logging
from typing import Any, Dict, List, Optional

from obsidian_cli import ObsidianCLI, detect_obsidian_binary

logger = logging.getLogger(__name__)


class CLIFileTools:
    """
    Async wrapper around ObsidianCLI providing the same public interface as FileTools.

    Key differences from FileTools:
    - No WebSocket server dependency — stateless subprocess calls per operation
    - Vault resolved from CLI registry; no heartbeat or connection tracking required
    - create_note_with_template uses Templater JS API via eval (non-interactive)
    - Periodic Notes folder paths derived from plugin config on disk or via eval
    """

    def __init__(
        self,
        cli: ObsidianCLI,
        default_vault: Optional[str] = None,
        template_sources: Optional[List[Dict[str, Any]]] = None,
    ):
        """
        Args:
            cli: ObsidianCLI instance with binary path set
            default_vault: Default vault name to use when vault_id=None.
                           Populated from vault registry on startup.
            template_sources: Day77.01 native template engine — ordered list of
                           {vault_id, folder, label, registry} configured in
                           plugin settings (templateSources). Empty/None keeps
                           create_note_with_template on the frozen legacy path.
        """
        self.cli = cli
        self._default_vault = default_vault
        self._vault_paths: Dict[str, str] = {}  # name → filesystem path (for Periodic Notes config)
        self._template_sources = template_sources or []

    def update_template_sources(self, template_sources: Optional[List[Dict[str, Any]]]) -> None:
        """Update configured template sources at runtime (Task 3b
        follow-up #3, Day77.01) — single entry point for any future
        settings-reload path that updates sources on this already-running
        instance instead of via a full process restart. Always invalidates
        the underlying ObsidianCLI's registry-discovery cache so a stale
        resolved (or previously-missing) Base path can't outlive the
        config that produced it.
        """
        self._template_sources = template_sources or []
        self.cli.invalidate_registry_cache()

    @classmethod
    def from_detected_binary(cls, default_vault: Optional[str] = None) -> "CLIFileTools":
        """Auto-detect binary and return ready instance. No subprocess calls at init time."""
        cli = ObsidianCLI.from_detected_binary()
        return cls(cli, default_vault)

    # ─── Vault Resolution ────────────────────────────────────────────────────

    def _resolve_vault(self, vault_id: Optional[str]) -> tuple[str | None, dict | None]:
        """
        Resolve vault name. Returns (vault_name, error_dict).
        Mirrors FileTools._validate_vault_connection() return signature.
        """
        if vault_id:
            return vault_id, None
        if self._default_vault:
            return self._default_vault, None
        return None, {
            "success": False,
            "error": "No vault specified and no default vault set.",
            "error_code": "NO_ACTIVE_VAULT",
        }

    def _vault_path(self, vault: str) -> Optional[str]:
        return self._vault_paths.get(vault)

    # ─── Public API — matches FileTools method signatures ────────────────────

    async def search_obsidian_notes(
        self,
        query: str = "",
        vault_id: Optional[str] = None,
        search_mode: str = "both",
        max_results: int = 100,
        include_context: bool = True,
        path: Optional[str] = None,
        property_filter: Optional[dict] = None,
        mtime_after: Optional[str] = None,
        mtime_before: Optional[str] = None,
    ) -> Dict[str, Any]:
        vault, err = self._resolve_vault(vault_id)
        if err:
            return err
        return await asyncio.to_thread(
            self.cli.search_obsidian_notes,
            vault, query, search_mode, max_results, include_context, path,
            property_filter, mtime_after, mtime_before,
        )

    async def read_obsidian_note(
        self,
        path: str,
        vault_id: Optional[str] = None,
        include_line_map: bool = False,
    ) -> Dict[str, Any]:
        if isinstance(include_line_map, str):
            include_line_map = include_line_map.lower() in ("true", "1", "yes")
        vault, err = self._resolve_vault(vault_id)
        if err:
            return err
        return await asyncio.to_thread(
            self.cli.read_obsidian_note, vault, path, include_line_map
        )

    async def update_obsidian_note(
        self,
        path: str,
        content: Optional[str] = None,
        vault_id: Optional[str] = None,
        editing_mode: str = "full_file",
        frontmatter_changes: Optional[Dict[str, Any]] = None,
        append_content: Optional[str] = None,
        replacement_content: Optional[str] = None,
        range_start_line: Optional[int] = None,
        range_start_char: Optional[int] = None,
        range_end_line: Optional[int] = None,
        range_end_char: Optional[int] = None,
        **kwargs,
    ) -> Dict[str, Any]:
        if isinstance(frontmatter_changes, str):
            try:
                frontmatter_changes = json.loads(frontmatter_changes)
            except (ValueError, TypeError):
                frontmatter_changes = None
        if isinstance(range_start_line, str):
            try:
                range_start_line = int(range_start_line)
            except (ValueError, TypeError):
                range_start_line = None
        if isinstance(range_end_line, str):
            try:
                range_end_line = int(range_end_line)
            except (ValueError, TypeError):
                range_end_line = None
        vault, err = self._resolve_vault(vault_id)
        if err:
            return err
        return await asyncio.to_thread(
            self.cli.update_obsidian_note,
            vault, path, editing_mode, content, append_content,
            frontmatter_changes, replacement_content,
            range_start_line, range_end_line,
        )

    async def create_obsidian_note(
        self,
        path: str,
        content: str = "",
        vault_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        vault, err = self._resolve_vault(vault_id)
        if err:
            return err
        return await asyncio.to_thread(self.cli.create_obsidian_note, vault, path, content)

    async def list_obsidian_vaults(self, vault_id: Optional[str] = None) -> Dict[str, Any]:
        result = await asyncio.to_thread(self.cli.list_obsidian_vaults)
        # Refresh cached vault paths
        if result.get("success"):
            for v in result["payload"].get("vaults", []):
                self._vault_paths[v["name"]] = v.get("path", "")
        return result

    async def explore_vault_folders(
        self,
        vault_id: Optional[str] = None,
        path: Optional[str] = None,
        query: Optional[str] = None,
        format: str = "smart",
        max_depth: int = 10,
        include_files: bool = False,
        extension_filter: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        vault, err = self._resolve_vault(vault_id)
        if err:
            return err
        return await asyncio.to_thread(
            self.cli.explore_vault_folders,
            vault, path, include_files, extension_filter, max_depth, query,
        )

    async def create_note_with_template(
        self,
        request_type: str,
        file_name: str,
        content: str = "",
        target_folder: str = "",
        vault_id: Optional[str] = None,
        template_source: Optional[Any] = None,
    ) -> Dict[str, Any]:
        vault, err = self._resolve_vault(vault_id)
        if err:
            return err

        # Day77.01: native multi-source engine takes over folder/template
        # resolution entirely when template_sources is configured — skip the
        # legacy Periodic-Notes-mapping pre-resolution below in that case,
        # since the native engine's own precedence ladder (Architecture Notes)
        # supersedes it and re-deriving target_folder here would just be
        # overridden anyway.
        if self._template_sources:
            # A source's empty vault_id means "wherever these settings live"
            # (the home vault this MCP instance was configured against), NOT
            # the vault this particular call is writing to — otherwise
            # cross-vault writes (the whole point of this feature) would look
            # for templates inside the destination vault and find nothing.
            home_vault = self._default_vault or vault
            resolved_sources = [
                {**source, "vault_id": source.get("vault_id") or home_vault}
                for source in self._template_sources
            ]
            return await asyncio.to_thread(
                self.cli.create_note_with_template,
                vault, request_type, file_name, content, target_folder,
                resolved_sources, template_source,
            )

        # Resolve target_folder from Periodic Notes config if not provided
        resolved_folder = target_folder
        if not resolved_folder:
            try:
                vault_path = self._vault_path(vault)
                mappings_result = await asyncio.to_thread(
                    self.cli.get_template_mappings, vault, vault_path
                )
                if mappings_result.get("success"):
                    template_mappings = mappings_result["payload"].get("templateMappings", {})
                    request_lower = request_type.lower()
                    for tname, tfolder in template_mappings.items():
                        if request_lower in tname.lower() or tname.lower() in request_lower:
                            resolved_folder = tfolder
                            logger.info(f"[CLI] Resolved folder '{resolved_folder}' for template '{request_type}'")
                            break
            except Exception as e:
                logger.warning(f"[CLI] Template mapping lookup failed: {e}")

        return await asyncio.to_thread(
            self.cli.create_note_with_template,
            vault, request_type, file_name, content, resolved_folder,
        )

    async def manage_obsidian_notes(
        self,
        operation: str,
        path: str,
        vault_id: Optional[str] = None,
        newPath: Optional[str] = None,
        target_vault_id: Optional[str] = None,
        target_path: Optional[str] = None,
        overwrite: bool = False,
    ) -> Dict[str, Any]:
        if operation in ("copy_to_vault", "move_to_vault"):
            return await self._manage_notes_cross_vault(
                operation, path, vault_id, target_vault_id, target_path, overwrite
            )
        vault, err = self._resolve_vault(vault_id)
        if err:
            return err
        return await asyncio.to_thread(
            self.cli.manage_obsidian_notes, vault, operation, path, newPath
        )

    async def _manage_notes_cross_vault(
        self,
        operation: str,
        path: str,
        vault_id: Optional[str],
        target_vault_id: Optional[str],
        target_path: Optional[str],
        overwrite: bool,
    ) -> Dict[str, Any]:
        """Day75.05: orchestrate copy_to_vault / move_to_vault across two vaults
        via sequenced CLI calls (no native cross-vault Vault API exists).
        """
        if isinstance(overwrite, str):
            overwrite = overwrite.lower() in ("true", "1", "yes")
        vault, err = self._resolve_vault(vault_id)
        if err:
            return err
        if not target_vault_id:
            return {
                "success": False,
                "error": "target_vault_id is required for copy_to_vault/move_to_vault",
                "error_code": "MISSING_TARGET_VAULT",
            }
        if not target_path:
            return {
                "success": False,
                "error": "target_path is required for copy_to_vault/move_to_vault",
                "error_code": "MISSING_TARGET_PATH",
            }
        fn = (
            self.cli.copy_note_cross_vault
            if operation == "copy_to_vault"
            else self.cli.move_note_cross_vault
        )
        return await asyncio.to_thread(fn, vault, path, target_vault_id, target_path, overwrite)

    async def copy_note_cross_vault(
        self,
        path: str,
        target_path: str,
        vault_id: Optional[str] = None,
        target_vault_id: Optional[str] = None,
        overwrite: bool = False,
    ) -> Dict[str, Any]:
        return await self.manage_obsidian_notes(
            "copy_to_vault", path, vault_id,
            target_vault_id=target_vault_id, target_path=target_path, overwrite=overwrite,
        )

    async def move_note_cross_vault(
        self,
        path: str,
        target_path: str,
        vault_id: Optional[str] = None,
        target_vault_id: Optional[str] = None,
        overwrite: bool = False,
    ) -> Dict[str, Any]:
        return await self.manage_obsidian_notes(
            "move_to_vault", path, vault_id,
            target_vault_id=target_vault_id, target_path=target_path, overwrite=overwrite,
        )

    async def manage_obsidian_folders(
        self,
        operation: str,
        folderPath: str,
        vault_id: Optional[str] = None,
        newFolderPath: Optional[str] = None,
    ) -> Dict[str, Any]:
        vault, err = self._resolve_vault(vault_id)
        if err:
            return err
        return await asyncio.to_thread(
            self.cli.manage_obsidian_folders, vault, operation, folderPath, newFolderPath
        )

    async def sync_obsidian_note(
        self,
        path: str,
        vault_id: Optional[str] = None,
        database_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Trigger MegaMem sync for a specific note.

        Without database_id: unchanged zero-arg command-by-ID transport
        (self.cli.trigger_sync) — Obsidian's Command.callback takes no
        arguments, so this path can never carry a database target.

        With database_id: routes through the CLI eval transport (Day86.04
        Task 5, self.cli.trigger_sync_for_database) — the same
        app.plugins.getPlugin('megamem-mcp') pattern used throughout
        obsidian_cli.py — carrying {path, database_id} directly to
        SyncStatusManager.enqueue()'s already-targetDb-aware sync path.
        WebSocket is deprecated for this deployment; no WS/RPC bridge is
        used or required.
        """
        vault, err = self._resolve_vault(vault_id)
        if err:
            return err

        if not database_id:
            return await asyncio.to_thread(self.cli.trigger_sync, vault, path)

        return await asyncio.to_thread(
            self.cli.trigger_sync_for_database, vault, path, database_id
        )

    # ─── Legacy method aliases (match FileTools method names called by MCP server) ──

    async def rename_obsidian_note(
        self, path: str, new_path: Optional[str], vault_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self.manage_obsidian_notes("rename", path, vault_id, new_path)

    async def delete_obsidian_note(
        self, path: str, vault_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self.manage_obsidian_notes("delete", path, vault_id)

    async def create_obsidian_folder(
        self, folder_path: str, vault_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self.manage_obsidian_folders("create", folder_path, vault_id)

    async def rename_obsidian_folder(
        self, folder_path: str, new_folder_path: Optional[str], vault_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self.manage_obsidian_folders("rename", folder_path, vault_id, new_folder_path)

    async def delete_obsidian_folder(
        self, folder_path: str, vault_id: Optional[str] = None
    ) -> Dict[str, Any]:
        return await self.manage_obsidian_folders("delete", folder_path, vault_id)

    # ─── Bases Tools ────────────────────────────────────────────────────────────

    async def manage_obsidian_base(
        self,
        operation: str,
        file: Optional[str] = None,
        path: Optional[str] = None,
        view: Optional[str] = None,
        format: str = "json",
        name: Optional[str] = None,
        content: Optional[str] = None,
        vault_id: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Route Bases operations by operation param to the underlying method.
        operation: 'list' | 'views' | 'query' | 'create'
        """
        if operation == "list":
            return await self.list_bases(vault_id=vault_id)
        elif operation == "views":
            return await self.list_base_views(file=file, path=path, vault_id=vault_id)
        elif operation == "query":
            return await self.query_base(file=file, path=path, view=view, format=format, vault_id=vault_id, limit=limit)
        elif operation == "create":
            return await self.create_base_item(file=file, path=path, view=view, name=name, content=content, vault_id=vault_id)
        else:
            return {
                "success": False,
                "error": f"Unknown operation '{operation}'. Use 'list', 'views', 'query', or 'create'.",
                "error_code": "INVALID_OPERATION",
            }

    async def list_bases(self, vault_id: Optional[str] = None) -> Dict[str, Any]:
        vault, err = self._resolve_vault(vault_id)
        if err:
            return err
        return await asyncio.to_thread(self.cli.list_bases, vault)

    async def list_base_views(
        self,
        file: Optional[str] = None,
        path: Optional[str] = None,
        vault_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        vault, err = self._resolve_vault(vault_id)
        if err:
            return err
        return await asyncio.to_thread(self.cli.list_base_views, vault, file, path)

    async def query_base(
        self,
        file: Optional[str] = None,
        path: Optional[str] = None,
        view: Optional[str] = None,
        format: str = "json",
        vault_id: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> Dict[str, Any]:
        vault, err = self._resolve_vault(vault_id)
        if err:
            return err
        return await asyncio.to_thread(self.cli.query_base, vault, file, path, view, format, limit)

    async def create_base_item(
        self,
        file: Optional[str] = None,
        path: Optional[str] = None,
        view: Optional[str] = None,
        name: Optional[str] = None,
        content: Optional[str] = None,
        vault_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        vault, err = self._resolve_vault(vault_id)
        if err:
            return err
        return await asyncio.to_thread(
            self.cli.create_base_item, vault, file, path, view, name, content
        )

    # ─── Connected Vault Helpers (replaces WebSocket VaultRegistry API) ──────

    def get_connected_vaults(self) -> List[str]:
        """Return list of known vault names (replaces WebSocketServer.get_connected_vaults)."""
        result = self.cli.list_obsidian_vaults()
        if result.get("success"):
            return [v["name"] for v in result["payload"]["vaults"]]
        return []

    def get_active_vault(self) -> Optional[str]:
        """Return the default vault name."""
        return self._default_vault

    def set_active_vault(self, vault_name: str) -> None:
        """Set the default vault for subsequent calls."""
        self._default_vault = vault_name
        logger.info(f"[CLI] Active vault set to: {vault_name}")

    def is_cli_backend(self) -> bool:
        """Marker method for runtime detection. FileTools does not have this."""
        return True
