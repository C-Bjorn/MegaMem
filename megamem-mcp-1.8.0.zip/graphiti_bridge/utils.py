"""
Utility functions for Graphiti Bridge

Helper functions for text processing, frontmatter extraction, logging, and response formatting.
"""

import os
import re
import json
import logging
import sys
from typing import Dict, Any, Optional, Tuple, List
from pathlib import Path
from datetime import datetime

# Optional YAML import for frontmatter parsing
YAML_AVAILABLE = False
try:
    import yaml  # type: ignore[import]
    YAML_AVAILABLE = True
except ImportError:
    yaml = None  # type: ignore[assignment]

# TEMP DEBUG: Force stderr output to see if anything works
# Debug logging bridge functions

# @purpose: Global debug flag and stderr logging functions to replace broken Python logging
# @depends: sys.stderr, json for structured output
# @results: Clean debug messages in consolidated.log, stdout preserved for JSON bridge

DEBUG_ENABLED = False


def set_debug_enabled(enabled: bool):
    """Set global debug flag"""
    global DEBUG_ENABLED
    DEBUG_ENABLED = enabled


def debug_log(message: str, tag: str = "PYTHON", data: Optional[dict] = None):
    """Simple stderr logger - TypeScript will add timestamps"""
    if DEBUG_ENABLED:
        print(f"[{tag}] {message}", file=sys.stderr, flush=True)
        if data:
            pretty = json.dumps(data, ensure_ascii=False, indent=2)
            indented = "\n".join("  " + line for line in pretty.splitlines())
            print(f"  Data: {indented}", file=sys.stderr, flush=True)


class DebugLogger:
    """Bridge logger that routes to debug_log while preserving existing API"""

    def __init__(self, debug_enabled: bool):
        self.debug_enabled = debug_enabled

    def debug(self, msg, *args):

        if self.debug_enabled:
            debug_log(msg % args if args else msg, "DEBUG")

    def info(self, msg, *args):

        if self.debug_enabled:
            debug_log(msg % args if args else msg, "INFO")

    def warning(self, msg, *args):

        debug_log(msg % args if args else msg, "WARN")  # Always show warnings

    def error(self, msg, *args):

        debug_log(msg % args if args else msg, "ERROR")  # Always show errors

    def exception(self, msg, *args):

        debug_log(f"EXCEPTION: {msg % args if args else msg}", "ERROR")


def setup_logging(debug: bool = False) -> DebugLogger:
    """Return bridge logger instead of Python's logging module"""
    set_debug_enabled(debug)

    # Override logging.getLogger to return our DebugLogger for graphiti_bridge loggers
    original_getLogger = logging.getLogger
    debug_logger_instance = DebugLogger(debug)

    def patched_getLogger(name=None):
        if name and ('graphiti_bridge' in name or 'graphiti_core' in name):
            return debug_logger_instance
        return original_getLogger(name)

    logging.getLogger = patched_getLogger
    return debug_logger_instance


def extract_frontmatter(content: str) -> Tuple[Dict[str, Any], str]:
    """
    Extract YAML frontmatter from markdown content

    Returns:
        Tuple of (frontmatter_dict, content_without_frontmatter)
    """
    frontmatter = {}
    remaining_content = content

    # Check for YAML frontmatter (--- at start and end)
    frontmatter_pattern = r'^---\s*\n(.*?)\n---\s*\n'
    match = re.match(frontmatter_pattern, content, re.DOTALL)

    if match:
        frontmatter_text = match.group(1)
        try:
            if YAML_AVAILABLE and yaml:
                parsed = yaml.safe_load(frontmatter_text)
                frontmatter = parsed if isinstance(parsed, dict) else {}
                remaining_content = content[match.end():]
            else:
                # Fallback to simple key-value parsing if PyYAML not available
                frontmatter = parse_simple_frontmatter(frontmatter_text)
                remaining_content = content[match.end():]
        except Exception as e:
            logging.warning(f"Failed to parse frontmatter: {e}")
            # Keep original content if parsing fails

    return frontmatter, remaining_content


def parse_simple_frontmatter(frontmatter_text: str) -> Dict[str, Any]:
    """
    Simple frontmatter parser fallback for when PyYAML is not available
    Handles basic key: value pairs
    """
    frontmatter = {}

    for line in frontmatter_text.split('\n'):
        line = line.strip()
        if ':' in line and not line.startswith('#'):
            key, value = line.split(':', 1)
            key = key.strip()
            value = value.strip()

            # Remove quotes if present
            if value.startswith('"') and value.endswith('"'):
                value = value[1:-1]
            elif value.startswith("'") and value.endswith("'"):
                value = value[1:-1]

            # Convert basic types
            if value.lower() in ('true', 'false'):
                value = value.lower() == 'true'
            elif value.isdigit():
                value = int(value)
            elif value.count('.') == 1 and value.replace('.', '').isdigit():
                value = float(value)

            frontmatter[key] = value

    return frontmatter


def extract_text_content(content: str) -> str:
    """
    Extract text content from markdown for Graphiti episode body.

    PRESERVES: headers (#), bold/italic (**bold**, *italic*), wikilinks ([[...]]),
               bullet lists (- item), blockquotes (> text), inline code (`code`).
    STRIPS: fenced code blocks (```...```), HTML tags, external link URLs.

    Rationale: Graphiti passes episode_body as a raw string directly to the LLM with no
    internal preprocessing. Modern LLMs handle markdown natively. Structural cues improve
    entity/relationship extraction quality. Code blocks are stripped to reduce token cost —
    Graphiti's extraction pipeline ignores them by default (confirmed issue #1299).
    """
    # Remove frontmatter
    _, clean_content = extract_frontmatter(content)

    # Strip fenced code blocks — reduces token cost; LLM extraction ignores them anyway
    clean_content = re.sub(r'```[^\n]*\n.*?```', '', clean_content, flags=re.DOTALL)

    # Strip HTML tags — noise with no semantic value for extraction
    clean_content = re.sub(r'<[^>]+>', '', clean_content)

    # Simplify external markdown links [text](url) -> text (keep label, drop URL noise)
    clean_content = re.sub(r'\[([^\]]+)\]\([^\)]+\)', r'\1', clean_content)

    # Clean up whitespace artifacts from stripped blocks
    clean_content = re.sub(r'\n\s*\n\s*\n', '\n\n', clean_content)  # 3+ newlines -> double
    clean_content = clean_content.strip()

    return clean_content


def format_success_response(processed: int = 0, skipped: int = 0, **kwargs) -> str:
    """Format a success response as JSON"""
    response = {
        'status': 'success',
        'processed': processed,
        'skipped': skipped,
        'timestamp': datetime.utcnow().isoformat(),
        **kwargs
    }
    return json.dumps(response)


def format_error_response(message: str, details: Optional[str] = None, **kwargs) -> str:
    """Format an error response as JSON"""
    response = {
        'status': 'error',
        'message': message,
        'timestamp': datetime.utcnow().isoformat(),
        **kwargs
    }

    if details:
        response['details'] = details

    return json.dumps(response)


def format_progress_response(current: int, total: int, message: str = "", **kwargs) -> str:
    """Format a progress update response as JSON"""
    response = {
        'status': 'progress',
        'current': current,
        'total': total,
        'progress': round((current / total * 100), 1) if total > 0 else 0,
        'message': message,
        'timestamp': datetime.utcnow().isoformat(),
        **kwargs
    }
    return json.dumps(response)


def safe_file_read(file_path: str, encoding: str = 'utf-8') -> Optional[str]:
    """
    Safely read a file with fallback encoding options

    Returns None if file cannot be read
    """
    try:
        with open(file_path, 'r', encoding=encoding) as f:
            return f.read()
    except UnicodeDecodeError:
        # Try with different encodings
        for fallback_encoding in ['utf-8-sig', 'latin1', 'cp1252']:
            try:
                with open(file_path, 'r', encoding=fallback_encoding) as f:
                    content = f.read()
                    logging.warning(
                        f"File {file_path} read with {fallback_encoding} encoding")
                    return content
            except UnicodeDecodeError:
                continue

        logging.error(f"Could not read file {file_path} with any encoding")
        return None
    except Exception as e:
        logging.error(f"Error reading file {file_path}: {e}")
        return None


def validate_note_file(file_path: str) -> bool:
    """
    Validate that a note file exists and is readable
    """
    path = Path(file_path)

    if not path.exists():
        logging.error(f"Note file does not exist: {file_path}")
        return False

    if not path.is_file():
        logging.error(f"Path is not a file: {file_path}")
        return False

    if not file_path.lower().endswith(('.md', '.markdown', '.txt')):
        logging.warning(f"File may not be a text file: {file_path}")

    # Try to read the file
    content = safe_file_read(file_path)
    if content is None:
        return False

    return True


def sanitize_property_name(name: str) -> str:
    """
    Sanitize property names for use in graph databases

    - Remove or replace invalid characters
    - Ensure valid identifier format
    """
    # Replace spaces and special characters with underscores
    sanitized = re.sub(r'[^a-zA-Z0-9_]', '_', name)

    # Ensure it doesn't start with a number
    if sanitized and sanitized[0].isdigit():
        sanitized = f"prop_{sanitized}"

    # Remove consecutive underscores
    sanitized = re.sub(r'_+', '_', sanitized)

    # Remove leading/trailing underscores
    sanitized = sanitized.strip('_')

    # Ensure non-empty
    if not sanitized:
        sanitized = "property"

    return sanitized


def chunk_list(items: list, chunk_size: int):
    """
    Split a list into chunks of specified size
    """
    for i in range(0, len(items), chunk_size):
        yield items[i:i + chunk_size]


def get_file_modification_time(file_path: str) -> Optional[datetime]:
    """
    Get the modification time of a file
    """
    try:
        path = Path(file_path)
        if path.exists():
            return datetime.fromtimestamp(path.stat().st_mtime)
    except Exception as e:
        logging.error(f"Error getting modification time for {file_path}: {e}")
    return None


def print_json_response(response_dict: dict):
    """
    Print a response as JSON to stdout (for TypeScript to capture)
    """
    print(json.dumps(response_dict, ensure_ascii=False,
          separators=(',', ':')), flush=True)


def print_final_json_response(response_dict: dict):
    """
    Print the final result JSON response to stdout with explicit formatting

    CRITICAL: This function MUST ONLY print to stdout - never to stderr.
    TypeScript expects the final JSON result on stdout for the bridge communication.
    All debug/diagnostic logging should go through the DebugLogger to stderr.
    """
    # Ensure clean JSON output for final response
    json_str = json.dumps(
        response_dict, ensure_ascii=False, separators=(',', ':'))
    print(json_str, flush=True)


# Day79.02 Task 2.1 — attribute-length-cap drop instrumentation.
#
# graphiti-core's cap_string_attributes() (attribute_utils.py) already computes the
# set of dropped/retained-over-cap fields but both call sites discard it
# (`merged, _ = apply_capped_attributes(...)`). It DOES log internally via the
# `graphiti_core.utils.maintenance.attribute_utils` logger, so rather than patching
# graphiti_core (disallowed per DevDoc Rev 5 Sec.3), we attach a logging.Handler
# directly to that logger and surface what it captured in the sync result JSON.
ATTRIBUTE_CAP_LOGGER_NAME = 'graphiti_core.utils.maintenance.attribute_utils'
ATTRIBUTE_CAP_ENV_VAR = 'GRAPHITI_ATTRIBUTE_MAX_LENGTH'


class AttributeCapCaptureHandler(logging.Handler):
    """Captures graphiti-core's attribute_length_cap_exceeded /
    attribute_length_cap_skipped_required log records so drops can be surfaced in the
    sync result JSON instead of only reaching a log file.

    Reads structured fields from record.args (the values the module passed into its
    %s-style logger call) rather than regex-parsing the formatted message string.
    """

    def __init__(self):
        super().__init__(level=logging.INFO)
        self.records: List[dict] = []

    def clear(self) -> None:
        self.records = []

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = record.msg or ''
            if msg.startswith('attribute_length_cap_exceeded'):
                status = 'dropped'
            elif msg.startswith('attribute_length_cap_skipped_required'):
                status = 'retained_over_cap_required'
            else:
                return
            args = record.args or ()
            # record.args is typed by the stdlib logging stubs as
            # tuple[object, ...] | Mapping[str, object] (CPython substitutes a Mapping
            # only when a single positional Mapping arg is passed). attribute_utils
            # always logs 7 positional args, so this is never actually a Mapping at
            # runtime -- but Pylance can't prove that, since Mapping doesn't support
            # slicing. Narrow explicitly so args[:7] below is provably iterable.
            if not isinstance(args, tuple) or len(args) < 7:
                return
            prompt_name, group_id, entity_uuid, field_name, reason, length, cap = args[:7]
            self.records.append({
                'status': status,
                'prompt': prompt_name,
                'group_id': group_id,
                'entity_uuid': entity_uuid,
                'field': field_name,
                'reason': reason,
                'length': length,
                'cap': cap,
            })
        except Exception:
            pass  # Capture must never break the sync pipeline.


def install_attribute_cap_capture() -> AttributeCapCaptureHandler:
    """Attach a capture handler directly to graphiti_core's attribute_utils logger.

    Uses the module's own `logger` attribute (not `logging.getLogger(name)`) so this
    works correctly even when called after `setup_logging()` has monkey-patched
    `logging.getLogger` to intercept 'graphiti_core'-named loggers for the bridge's own
    DebugLogger. `cap_string_attributes` logs drops at INFO, so the target logger's
    level is raised from its default (WARNING, inherited from root) to INFO — otherwise
    the drop records would never reach any handler at all.

    Safe to call multiple times per process (daemon mode reuses the interpreter across
    notes) — any previously-installed capture handler is replaced, not stacked.
    """
    from graphiti_core.utils.maintenance import attribute_utils as _attribute_utils_mod
    target_logger = _attribute_utils_mod.logger
    for existing in list(target_logger.handlers):
        if isinstance(existing, AttributeCapCaptureHandler):
            target_logger.removeHandler(existing)
    handler = AttributeCapCaptureHandler()
    target_logger.addHandler(handler)
    target_logger.setLevel(logging.INFO)
    target_logger.propagate = False
    return handler


def summarize_attribute_cap_drops(handler: Optional[AttributeCapCaptureHandler]) -> dict:
    """Build the `dropped_attributes` summary attached to the sync result.

    Terminology per DevDoc Rev 4/5: values are DROPPED (absent), never "truncated".
    """
    if handler is None:
        return {
            'dropped_count': 0,
            'retained_over_cap_required_count': 0,
            'dropped': [],
            'retained_over_cap_required': [],
        }
    dropped = [r for r in handler.records if r['status'] == 'dropped']
    retained = [r for r in handler.records if r['status'] == 'retained_over_cap_required']
    return {
        'dropped_count': len(dropped),
        'retained_over_cap_required_count': len(retained),
        'dropped': dropped,
        'retained_over_cap_required': retained,
    }


def verify_attribute_cap_env_effect() -> dict:
    """Prove the GRAPHITI_ATTRIBUTE_MAX_LENGTH interim mitigation (Day79.02 Task 2.2)
    actually took effect, rather than assuming it. Calls graphiti-core's own resolver
    function directly (confirmed to read the env var at call time, not import time)
    so this is a real assertion of effect, not a re-implementation that could drift.
    """
    try:
        from graphiti_core.utils.maintenance.attribute_utils import (
            _resolve_default_max_length,
            DEFAULT_ATTRIBUTE_MAX_LENGTH,
        )
        resolved = _resolve_default_max_length(DEFAULT_ATTRIBUTE_MAX_LENGTH)
        env_raw = os.environ.get(ATTRIBUTE_CAP_ENV_VAR)
        took_effect = env_raw is not None and str(resolved) == str(int(env_raw))
        return {
            'env_var': ATTRIBUTE_CAP_ENV_VAR,
            'env_value': env_raw,
            'effective_max_length': resolved,
            'default_max_length': DEFAULT_ATTRIBUTE_MAX_LENGTH,
            'took_effect': took_effect,
        }
    except Exception as e:
        return {'error': str(e), 'took_effect': False}


def print_error_and_exit(message: str, details: Optional[str] = None, exit_code: int = 1):
    """
    Print an error response and exit
    """
    error_response = format_error_response(message, details)
    # Add type field for consistency with TypeScript expectations
    response_dict = json.loads(error_response)
    response_dict['type'] = 'result'  # Mark as final result even for errors
    final_error = json.dumps(
        response_dict, ensure_ascii=False, separators=(',', ':'))
    print(final_error, flush=True)
    sys.exit(exit_code)
